import React, { Component } from 'react';
class Platform extends Component {

  constructor(props) {
    super(props);
    this.state = {
      name: '',
      status: false,
      id :''
    }
  }

  onCloseForm = () => {
    this.props.onCloseForm();
  }

  onChange=(e)=>{
    this.setState({
      [e.target.name] : e.target.value
    })
  }
 
  onSubmit=(event)=>{
    event.preventDefault();
    this.props.onSubmit(this.state)
    this.onClear();
    this.onCloseForm();
  }
  
  onClear = () => {
      this.setState({
        name:'',
        status : false
      })
  }

  componentWillMount(){
    if(this.props.taskediting){
      this.setState({
        id : this.props.taskediting.id,
        name :this.props.taskediting.name,
        status:this.props.taskediting.status
      })
    }
  }

  componentWillReceiveMount(nextprops){
    if(nextprops.taskediting){
      this.setState({
        id : nextprops.taskediting.id,
        name :nextprops.taskediting.name,
        status:nextprops.taskediting.status
      })
    }

  }

  render() {
    return (
      <div className="col-4">
        <div className="card">
          <h5 className="card-header">Add Career&nbsp;&nbsp;&nbsp;
                <span
              className="fas fa-plus"
              onClick={this.onCloseForm}
            >
            </span>
          </h5>
          <div className="card-body">
            <form onSubmit={this.onSubmit}>
              <div className="form-group">
                <label>Name :</label>
                <input
                  type="text"
                  className="form-control"
                  name="name"
                  value={this.state.name}
                  onChange={this.onChange}
                />
                {/* <label >Email address</label> */}
                {/* <input type="email" className="form-control" /> */}
              </div>
              <div className="form-group">
                <label>Example select</label>
                <select
                  className="form-control"
                  name="status"
                  value={this.state.status}
                  onChange={this.onChange}
                >
                  <option value={true}>Activate</option>
                  <option value={false}>Pending</option>
                </select>
              </div>
              <button type="submit" className="btn btn-success">Save</button>&nbsp;
              <button type="button" className="btn btn-danger" onClick={this.onClear}><i className="far fa-trash-alt"></i>&nbsp;Delete</button>
            </form>
          </div>
        </div>
      </div>
    )
  }
}
export default Platform;