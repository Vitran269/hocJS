import React,{Component} from 'react';

class Control extends Component {
        render(){
            return (
                <div className="row">
                <div className="col-6">
                  <div className="input-group ">
                    <input type="text" className="form-control" placeholder="" />

                    <div className="input-group-append">
                      <button className="btn btn-secondary" type="button"><i className="fas fa-search"></i>&nbsp;Search</button>
                    </div>

                  </div>

                </div>
                <div className="col-8 mt-3">
                  <button className="btn btn-secondary" type="button"><i className="fas fa-sort"></i>&nbsp;Sort</button>
                </div>
              </div>
            )
        }
    }
export default Control;