import React, { Component } from 'react';

import './App.css';
import Platform from './components/Platform';
import Table from './components/Table';
import Control from './components/Control';
class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            tasks: [],
            isDisplayForm: false,
            taskediting :''
        }
    }

    componentWillMount=()=> {
        if (localStorage  && localStorage.getItem('tasks')) {
            var tasks = JSON.parse(localStorage.getItem('tasks'));
            this.setState({
                tasks: tasks
            });
        }
    }



    onGenerateData = () => {
        var tasks = [
            {
                id: 1,
                name: 'Study IT',
                status: true
            },
            {
                id: 2,
                name: 'Swimming',
                status: true
            },
            {
                id: 3,
                name: 'Eating',
                status: true
            }
        ];
        this.setState({
            tasks: tasks
        });
        localStorage.setItem('tasks', JSON.stringify(tasks));

    }

    s4() {
        return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
    }

    generateID() {
        return this.s4() + this.s4() + '-' + this.s4() + '-' + this.s4() + '-' + this.s4() + '-' + this.s4();
    }

    addCareer = () => {
        console.log(this.state.isDisplayForm);
        this.setState({
            isDisplayForm: !this.state.isDisplayForm
        })

    }

    onCloseForm = () => {
        this.setState({
            isDisplayForm: false
        })

    }
    

   
    onSubmit=(data)=>{
        var {tasks} = this.state
        var object = {
            id : this.generateID(),
            name : data.name,
            status : data.status
        }
        tasks.push(object);
        this.setState({

            tasks:tasks
        })
        localStorage.setItem('tasks',JSON.stringify(tasks))
    }
 findIndex = (id) =>{
     var {tasks} = this.state;
    var  result = -1;
     tasks.forEach((task,index)=>{
         if(task.id === id){
                result = index;
         }
         return result;
     })
 }
  onDelete = (id) => {
        var{tasks}=this.state;
        var index = this.findIndex(id);
        if (index !== -1){
            tasks.splice(index,1)
            this.setState({
                tasks : tasks
            })
            localStorage.setItem('tasks',JSON.stringify(tasks));
           
        }
        this.onCloseForm();
  }  
  onUpdate=(id)=>{
        var{tasks} =this.state
        var index = this.findIndex(id)
        var taskediting = tasks[index]
        this.setState({
            taskediting : taskediting
        })
  }

    render() {

        var { tasks, isDisplayForm } = this.state;
        var elmTaskForm = isDisplayForm ? <Platform onSubmit={this.onSubmit} onCloseForm={this.onCloseForm} taskediting={this.state.taskediting} /> : "";

        return (
            <div>
                <div className="container">
                    <div className="text-center ">
                        <h1>Business Management</h1>
                    </div>
                    <br />
                </div>
                <div className="container">
                    <div className="row">
                        {elmTaskForm }
                        <div className={isDisplayForm ? "col-8" : "col-12"}>
                            <div className="row">
                                <div className="col-6">
                                    <button type="button" className="btn btn-primary"
                                        onClick={this.addCareer}>Add Career
                  </button>
                                    <button
                                        type="button"
                                        className="btn btn-danger ml-2"
                                        onClick={this.onGenerateData}

                                    >Generate data</button>
                                </div>
                            </div> <br />
                            <Control />
                            <br />
                            <Table tasks={tasks} 
                           onDelete ={this.onDelete}
                           onUpdateStatus = {this.onUpdateStatus}
                           onUpdate ={this.onUpdate}
                            />
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default App;
